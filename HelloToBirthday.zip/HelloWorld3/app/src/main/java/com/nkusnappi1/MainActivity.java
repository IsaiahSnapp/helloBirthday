package com.nkusnappi1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.sql.SQLOutput;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            int a = 30, b = 0;
            int c = a/b;  // cannot divide by zero
            System.out.println(c);
        }
        catch(ArithmeticException e) {
            Log.e("Main Activity", "Error: Cannot Divide By Zero", e);
        }

    }
}